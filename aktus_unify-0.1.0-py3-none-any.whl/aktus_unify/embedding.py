import requests
from typing import Any, Dict
from uuid import uuid4

VECTOR_EMBEDDING_ENDPOINT = "http://34.44.14.39:8080/vectorindex/embed"

def create_embedding(
    # Required fields
    domain: str,
    usecase: str,
    # Optional fields
    embedding_model: str = "text-embedding-3-large",
    chunking_strategy: str = "semantic",
    metric_type: str = "cosine",
    endpoint_url: str = VECTOR_EMBEDDING_ENDPOINT,
    **kwargs: Dict[str, Any]
) -> Dict:
    """
    Create vector embeddings for a given text via the Aktus embedding microservice.

    The request payload is composed of:
    - id: A user-defined use case identifier.
    - domain: Main higher-level category of documents (e.g., 'advisory', 'audit', 'tax').
    - usecase: The specific use case name for the copilot (e.g., 'qna').
    - embedding_model: Model used for generating embeddings (e.g., 'text-embedding-3-large').
    - chunking_strategy: The strategy for chunking text (e.g., 'semantic').
    - metric_type: The metric used for similarity comparisons (e.g., 'cosine').

    Args:
        domain (str, optional): Document domain/category. Defaults to "advisory".
        usecase (str, optional): Use case name (e.g., 'qna'). Defaults to "qna".
        embedding_model (str, optional): The embedding model to use. 
            Defaults to "text-embedding-3-large".
        chunking_strategy (str, optional): Strategy for chunking ('semantic'). 
            Defaults to "semantic".
        metric_type (str, optional): Metric for search comparison ('cosine' or 'dotproduct'). 
            Defaults to "cosine".
        endpoint_url (str, optional): The endpoint for the embedding service. 
            Defaults to VECTOR_EMBEDDING_ENDPOINT.
        **kwargs: Additional keyword arguments.
            - id: A user-defined use case identifier. Defaults to uuid4().

    Returns:
        dict: A dictionary containing the embedding response from the microservice.
              Typically includes an "embedding" field with the vector data.
    """
    payload = {
        "id": kwargs.get("id", str(uuid4())),
        "domain": domain,
        "usecase": usecase,
        "embedding_model": embedding_model,
        "chunking_strategy": chunking_strategy,
        "metric_type": metric_type,
    }
    headers = {"accept": "application/json", "Content-Type": "application/json"}
    response = requests.post(endpoint_url, json=payload, headers=headers, timeout=120)
    response.raise_for_status()
    return response.json()

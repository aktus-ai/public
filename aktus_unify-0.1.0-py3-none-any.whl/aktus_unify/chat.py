import httpx
from typing import Any, Dict, AsyncGenerator


CHAT_ENDPOINT = "http://34.60.36.248:8080/chat/copilot"


async def ask_question(
    # Required fields
    user_question: str,
    domain: str,
    usecase: str,
    # Optional fields
    embedding_model: str = "text-embedding-3-large",
    chunking_strategy: str = "semantic",
    metric_type: str = "cosine",
    # LLM / VLM
    llm_model_name: str = "gpt-4o",
    llm_inference_server: str = "openai",
    vlm_model_name: str = "gpt-4o",
    vlm_inference_server: str = "openai",
    # Generation & retrieval parameters
    temperature: float = 0.0,
    top_k: int = 8,
    embeddings_weight: float = 0.7,
    rerank_method: str = "mmr",
    retrieval_method: str = "hybrid",
    cot_review: bool = False,
    refine_and_focus: bool = False,
    stream_mode: str = "word",
    # Additional fields
    chat_history: list = None,
    rewrite_question: str = "",
    decompose_question: str = "",
    debug_info: dict = None,
    endpoint_url: str = CHAT_ENDPOINT,
    **kwargs: Dict[str, Any]    
) -> AsyncGenerator:
    """
    Query the Aktus chat microservice to generate responses from an LLM, 
    optionally using a VLM and embedded retrieval.

    According to the documentation, this endpoint supports a variety of 
    parameters, including LLM model selection, temperature, top_k, retrieval 
    method, etc.

    Args:
        user_question (str): The user's question or prompt.
        domain (str, optional): Main category of documents (e.g., 'advisory'). 
            Defaults to "advisory".
        usecase (str, optional): Use case name (e.g., 'qna'). Defaults to "qna".
        embedding_model (str, optional): Model used for embeddings.
            Defaults to "text-embedding-3-large".
        chunking_strategy (str, optional): Strategy for chunking text. 
            Defaults to "semantic".
        metric_type (str, optional): Metric for search comparison 
            ('cosine' or 'dotproduct'). Defaults to "cosine".

        llm_model_name (str, optional): LLM model name to use. 
            E.g., 'gpt-4o', 'aktus'. Defaults to "gpt-4o".
        llm_inference_server (str, optional): The inference server for the LLM. 
            E.g., 'openai'. Defaults to "openai".

        vlm_model_name (str, optional): Vision Language Model name to use. 
            E.g., 'gpt-4o', 'aktus'. Defaults to "gpt-4o".
        vlm_inference_server (str, optional): The inference server for the VLM. 
            E.g., 'openai'. Defaults to "openai".

        temperature (float, optional): Controls randomness of generation 
            (0-1 range). Defaults to 0.0.
        top_k (int, optional): Number of top documents to retrieve. Defaults to 8.
        embeddings_weight (float, optional): Weight of semantically similar text 
            (0-1 range). Defaults to 0.7.
        rerank_method (str, optional): Reranking method (e.g., 'mmr', 'similarity'). 
            Defaults to "mmr".
        retrieval_method (str, optional): Method of retrieval (e.g., 'hybrid', 'semantic'). 
            Defaults to "hybrid".
        cot_review (bool, optional): Whether to display chain-of-thought. Defaults to False.
        refine_and_focus (bool, optional): Refine the RAG answer with VLM. Defaults to False.
        stream_mode (str, optional): How to stream responses ('word', 'step', 'block'). 
            Defaults to "word".

        chat_history (list, optional): Existing list of conversation messages. Defaults to None.
        rewrite_question (str, optional): If question rewriting is needed. Defaults to "string".
        decompose_question (str, optional): Decomposition of question. Defaults to "breakdown".
        debug_info (dict, optional): Additional debugging data. Defaults to None.
        endpoint_url (str, optional): The API endpoint for the chat service.
            Defaults to CHAT_ENDPOINT.
        **kwargs: Additional keyword arguments.
            - id: A user-defined use case identifier. Defaults to uuid4().

    Returns:
        AsyncGenerator: The response from the chat microservice, typically including 
              the generated text and any metadata from the RAG pipeline.
    """
    if chat_history is None:
        chat_history = []
    if debug_info is None:
        debug_info = {}

    payload = {
        "domain": domain,
        "usecase": usecase,
        "id": kwargs.get("id", 0),
        "embedding_model": embedding_model,
        "chunking_strategy": chunking_strategy,
        "metric_type": metric_type,
        "llm": {
            "model_name": llm_model_name,
            "inference_server": llm_inference_server
        },
        "vlm": {
            "model_name": vlm_model_name,
            "inference_server": vlm_inference_server
        },
        "temperature": temperature,
        "top_k": top_k,
        "embeddings_weight": embeddings_weight,
        "rerank_method": rerank_method,
        "retrieval_method": retrieval_method,
        "cot_review": cot_review,
        "stream_mode": stream_mode,
        "refine_and_focus": refine_and_focus,
        "chat_history": chat_history,
        "user_question": user_question,
        "rewrite_question": rewrite_question,
        "decompose_question": decompose_question,
        "debug_info": debug_info
    }
    # Make an asynchronous API request with streaming
    headers = {"accept": "application/json", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=300) as client:
        async with client.stream("POST", endpoint_url, json=payload, headers=headers) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line:
                    yield line

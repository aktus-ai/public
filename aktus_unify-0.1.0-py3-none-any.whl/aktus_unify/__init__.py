"""
aktus_unify
==========

A unified Python client for Aktus AI microservices.
"""

__version__ = "0.1.0"

from .ocr import check_tasks_status
from .embedding import create_embedding
from .chat import ask_question


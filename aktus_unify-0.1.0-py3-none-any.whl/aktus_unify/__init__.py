"""
aktus_unify
==========

A unified Python client for Aktus AI microservices.
"""

__version__ = "0.1.0"

from .chat import ask_question
from .embedding import create_embedding
from .tasks import check_tasks_status


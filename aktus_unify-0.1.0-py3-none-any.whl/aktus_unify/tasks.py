import requests
from typing import Dict, Any

# Base URL for the DB Manager service
DB_MANAGER_ENDPOINT = "http://34.57.143.239"


def check_task_status(task_id: str, endpoint_url: str = DB_MANAGER_ENDPOINT) -> Dict[str, Any]:
    """Retrieves the status of a task from the DB Manager service.

    Args:
        task_id (str): The task ID returned by the queueing system.

    Returns:
        Dict[str, Any]: The task details inc    luding status and result.

    Raises:
        requests.HTTPError: If the HTTP request fails or task is not found.
    """
    response = requests.get(
        f"{endpoint_url}/tasks/{task_id}", 
        timeout=10
    )
    response.raise_for_status()
    return response.json()

def check_tasks_status(task_ids: Dict[str, str], endpoint_url: str = DB_MANAGER_ENDPOINT) -> dict[str, str]:
    """Checks and prints the status of multiple tasks.

    Args:
        task_ids (Dict[str, str]): A dictionary mapping filenames to their task IDs.
        endpoint_url (str): The URL of the DB Manager service.
    
    Returns:
        dict[str, str]: A dictionary mapping filenames to their statuses.
    
    Note:
        This function prints the status of each task to stdout. Failed requests
        for individual tasks will print error messages but won't stop the function.
    """
    response_dict: dict[str, str] = {}

    for filename, task_id in task_ids.items():
        try:
            status_response = check_task_status(task_id, endpoint_url)
            response_dict[filename] = status_response['status']
        except requests.RequestException as e:
            print(f"{filename}: Error checking status - {str(e)}")

    return response_dict

import requests
from typing import Dict, Any
from colorama import init, Fore, Style

# Base URL for the DB Manager service
DB_MANAGER_ENDPOINT = "http://34.46.92.146"

init()  # Initialize colorama

def check_task_status(task_id: str, endpoint_url: str = DB_MANAGER_ENDPOINT) -> Dict[str, Any]:
    """Retrieves the status of a task from the DB Manager service.

    Args:
        task_id (str): The task ID returned by the queueing system.

    Returns:
        Dict[str, Any]: The task details including status and result.

    Raises:
        requests.HTTPError: If the HTTP request fails or task is not found.
    """
    response = requests.get(
        f"{endpoint_url}/tasks/{task_id}", 
        timeout=10
    )
    response.raise_for_status()
    return response.json()

def check_tasks_status(tasks):
    """
    Check the status of OCR tasks and display results in a user-friendly format.
    
    Args:
        tasks (list): List of OCR task objects to check
    """
    print("\n=== OCR Tasks Status ===\n")
    
    for i, task in enumerate(tasks, 1):
        status = task.get_task_status()
        
        # Format the task ID/name
        task_id = task.task_id if hasattr(task, 'task_id') else f"Task {i}"
        
        # Color-code and format status messages
        if status['status'] == 'completed':
            status_color = Fore.GREEN
            status_msg = "✓ COMPLETED"
        elif status['status'] == 'processing':
            status_color = Fore.YELLOW
            status_msg = "⟳ PROCESSING"
        elif status['status'] == 'failed':
            status_color = Fore.RED
            status_msg = "✗ FAILED"
        else:
            status_color = Fore.WHITE
            status_msg = status['status'].upper()
            
        # Print formatted task information
        print(f"{Fore.CYAN}Task ID:{Style.RESET_ALL} {task_id}")
        print(f"{Fore.CYAN}Status:{Style.RESET_ALL} {status_color}{status_msg}{Style.RESET_ALL}")
        
        # Show progress if available
        if 'progress' in status:
            progress = status['progress']
            progress_bar = "█" * int(progress * 20)
            remaining_bar = "░" * (20 - int(progress * 20))
            print(f"{Fore.CYAN}Progress:{Style.RESET_ALL} [{progress_bar}{remaining_bar}] {progress*100:.1f}%")
        
        # Show error message if failed
        if status['status'] == 'failed' and 'error' in status:
            print(f"{Fore.RED}Error:{Style.RESET_ALL} {status['error']}")
            
        # Add separator between tasks
        print("-" * 50 + "\n")
